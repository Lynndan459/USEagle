<?php
$send="thedeecash@yandex.com"// your email
?>